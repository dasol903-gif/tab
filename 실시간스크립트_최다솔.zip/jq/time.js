$(function(){
  var $ul = $('#ticker');
  var h = $ul.children('li').outerHeight(); 

  setInterval(function(){
    $ul.animate({marginTop: -h}, 300, function(){
      $ul.children('li:first').appendTo($ul);
      $ul.css('marginTop', 0);
    });
  }, 3000);
});