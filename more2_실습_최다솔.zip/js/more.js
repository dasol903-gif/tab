$(function () {
    function listMore() {
        const $items = $('#bestseller_box li');
        const totalItems = $items.length;
        let showCount = 0;

        // 현재 화면 너비 기준으로 한 번에 보여줄 개수 설정
        const winWidth = $(window).width();
        if (winWidth <= 640) {
            showCount = 2;
        } else if (winWidth <= 768) {
            showCount = 3;
        } else {
            showCount = 4;
        }

        // 초기 상태 설정
        $items.hide();
        $items.slice(0, showCount).show();
/*
.off('click')
기존에 등록되어 있던 클릭 이벤트 핸들러를 제거
중복 등록을 방지하기 위해 이벤트를 먼저 제거하고 새로 등록
*/
        $('.more_btn').off('click').on('click', function () {
            let visibleCount = $('#bestseller_box li:visible').length;
            let nextCount = visibleCount + showCount;
            if (nextCount > totalItems) nextCount = totalItems;

            $items.slice(0, nextCount).show();

            // 더 이상 보여줄 항목이 없다면 버튼 숨기기
            if (nextCount === totalItems) {
                $('.more_btn').hide();
            }
        });

        // 버튼 초기화 상태 (처음에 전체 안 보여주면 보여줌)
        if (showCount < totalItems) {
            $('.more_btn').show();
        } else {
            $('.more_btn').hide();
        }
    }

    listMore();

    // 창 크기 변경 시 다시 적용
    $(window).on('resize', function () {
        listMore();
    });
});