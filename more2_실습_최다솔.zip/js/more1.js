$(function () {
    const $items = $('#bestseller_box li');
    const totalItems = $items.length;
    let visibleCount = 0;

    function getShow() {
        const winWidth = $(window).width();
        if (winWidth <= 640) {
            return 2;
        } else if (winWidth <= 768) {
            return 3;
        } else {
            return 4;
        }
    }

    function update(countToShow) {
        // 모두 숨기고 필요한 만큼만 보여주기
        $items.hide();
        $items.slice(0, countToShow).show();

        // More 버튼 보이기/숨기기
        if (countToShow >= totalItems) {
            $('.more_btn').hide();
        } else {
            $('.more_btn').show();
        }
    }

    function initializeList() {
        const showCount = getShow();
        // 기존 visibleCount와 비교해서 더 큰 수로 설정 (줄이지 않음)
        visibleCount = Math.max(visibleCount, showCount);
        update(visibleCount);
    }

    // 초기 실행
    initializeList();
    // More 버튼 클릭 시
    $('.more_btn').on('click', function () {
        const showCount = getShow();
        visibleCount += showCount;

        if (visibleCount > totalItems) {
            visibleCount = totalItems;
        }
        update(visibleCount);
    });

       // 창 크기 변경 시
       $(window).on('resize', function () {
        initializeList();
    });
});