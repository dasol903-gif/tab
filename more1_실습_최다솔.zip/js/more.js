// js/more.js
$(function () {
  const $list = $('.product-list');
  const $items = $list.find('> li');
  const $btn = $('.btn-more');

  if (!$list.length || !$items.length || !$btn.length) return;

  const total = $items.length;

  // 현재 화면 너비 기준 chunk 계산
  function getShowCount() {
    const w = $(window).width();
    if (w <= 640) return 2;     // mobile
    if (w <= 768) return 3;     // tablet
    return 4;                   // desktop
  }

  // 상태
  let baseChunk = getShowCount();
  let visibleCount = 0;

  function applyInitial() {
    baseChunk = getShowCount();
    // 이미 펼친 개수(사용자 클릭 진행분)를 유지하되, 최소 baseChunk는 보장
    visibleCount = Math.max(visibleCount || 0, baseChunk);

    // 초기/리스케일 렌더
    $items.hide().slice(0, visibleCount).show();

    // 버튼 표시/숨김
    toggleButton();
  }

  function showMore() {
    const next = Math.min(visibleCount + baseChunk, total);
    if (next > visibleCount) {
      $items.slice(visibleCount, next).fadeIn(180);
      visibleCount = next;
    }
    toggleButton();
  }

  function toggleButton() {
    if (visibleCount >= total) {
      $btn.attr('aria-expanded', 'true').hide();
    } else {
      $btn.attr('aria-expanded', 'false').show();
    }
  }

  // 클릭 바인딩(중복 방지)
  $btn.off('click.more').on('click.more', function () {
    showMore();
  });

  // 첫 렌더
  applyInitial();

  // 리사이즈: 그리드 단위 바뀌면 기준 재계산
  let rid = null;
  $(window).on('resize.more', function () {
    if (rid) cancelAnimationFrame(rid);
    rid = requestAnimationFrame(applyInitial);
  });
});
